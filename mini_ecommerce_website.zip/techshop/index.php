

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechShop - Your Tech Store</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }

        .navbar {
            background: linear-gradient(90deg, #4b6cb7 0%, #182848 100%);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .nav-logo {
            color: #fff;
            font-size: 1.8rem;
            font-weight: bold;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .nav-logo i {
            margin-right: 10px;
            color: #ff6b6b;
        }

        .nav-menu {
            display: flex;
            gap: 25px;
        }

        .nav-link {
            color: #fff;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            transition: all 0.3s;
            font-weight: 500;
        }

        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            transform: translateY(-2px);
        }

        .nav-cart {
            background-color: #ff6b6b;
            padding: 8px 15px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 20px;
        }

        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&auto=format&fit=crop&w=1500&q=80');
            background-size: cover;
            background-position: center;
            height: 400px;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: white;
            margin-bottom: 3rem;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 600px;
            margin-bottom: 2rem;
        }

        .btn {
            background-color: #ff6b6b;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 30px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn:hover {
            background-color: #ff5252;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(255, 107, 107, 0.4);
        }

        .section-title {
            text-align: center;
            margin-bottom: 2rem;
            color: #343a40;
            font-size: 2rem;
            position: relative;
            padding-bottom: 10px;
        }

        .section-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: linear-gradient(90deg, #4b6cb7 0%, #182848 100%);
            border-radius: 2px;
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 25px;
            margin-bottom: 3rem;
        }

        .product-card {
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            display: flex;
            flex-direction: column;
        }

        .product-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .product-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-bottom: 3px solid #f1f1f1;
        }

        .product-info {
            padding: 20px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .product-title {
            font-size: 1.2rem;
            margin-bottom: 10px;
            color: #343a40;
        }

        .product-description {
            color: #6c757d;
            margin-bottom: 15px;
            flex-grow: 1;
        }

        .product-price {
            font-weight: bold;
            font-size: 1.4rem;
            color: #28a745;
            margin-bottom: 15px;
        }

        .product-actions {
            display: flex;
            gap: 10px;
        }

        .add-to-cart-btn {
            background-color: #4b6cb7;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            flex-grow: 1;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .add-to-cart-btn:hover {
            background-color: #3a5999;
        }

        .view-details-btn {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
            text-decoration: none;
            text-align: center;
            font-size: 0.9rem;
        }

        .view-details-btn:hover {
            background-color: #5a6268;
        }

        .cart-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #28a745;
            color: white;
            padding: 15px 20px;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            display: none;
            z-index: 1000;
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from {
                transform: translateX(100px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        footer {
            background: linear-gradient(90deg, #4b6cb7 0%, #182848 100%);
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            padding: 0 20px;
        }

        .footer-section {
            flex: 1;
        }

        .footer-section h3 {
            margin-bottom: 1rem;
            font-size: 1.3rem;
        }

        .footer-section p {
            margin-bottom: 0.5rem;
        }

        .social-icons {
            display: flex;
            gap: 15px;
            margin-top: 1rem;
        }

        .social-icons a {
            color: white;
            font-size: 1.5rem;
            transition: color 0.3s;
        }

        .social-icons a:hover {
            color: #ff6b6b;
        }

        .copyright {
            text-align: center;
            padding-top: 2rem;
            margin-top: 2rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        @media (max-width: 768px) {
            .products-grid {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }
            
            .nav-menu {
                gap: 15px;
            }
            
            .hero h1 {
                font-size: 2.2rem;
            }
            
            .footer-content {
                flex-direction: column;
                gap: 2rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <a href="index.php" class="nav-logo">
                <i class="fas fa-laptop-code"></i> TechShop
            </a>
            <div class="nav-menu">
                <a href="index.php" class="nav-link">Home</a>
                <a href="#products" class="nav-link">Products</a>
                <a href="cart.php" class="nav-link">Cart</a>
                <a href="add_product.php" class="nav-link">Admin</a>
            </div>
            <a href="cart.php" class="nav-link nav-cart">
                <i class="fas fa-shopping-cart"></i>
                <span id="cart-count">0</span>
            </a>
        </div>
    </nav>

    <div class="container">
        <div class="hero">
            <h1>Welcome to TechShop</h1>
            <p>Discover the latest tech gadgets and electronics at amazing prices</p>
            <a href="#products" class="btn">Shop Now</a>
        </div>

        <h2 id="products" class="section-title">Featured Products</h2>
        
        <div class="products-grid">
            <!-- Product 1 -->
            <div class="product-card">
                <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80" alt="Wireless Headphones" class="product-image">
                <div class="product-info">
                    <h3 class="product-title">Wireless Headphones</h3>
                    <p class="product-description">High-quality wireless headphones with noise cancellation and 20-hour battery life.</p>
                    <p class="product-price">$99.99</p>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" onclick="addToCart(1, 'Wireless Headphones', 99.99, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80')">Add to Cart</button>
                        <a href="product_detail.php?id=1" class="view-details-btn">Details</a>
                    </div>
                </div>
            </div>

            <!-- Product 2 -->
            <div class="product-card">
                <img src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80" alt="Smartphone" class="product-image">
                <div class="product-info">
                    <h3 class="product-title">Smartphone</h3>
                    <p class="product-description">Latest smartphone with high-resolution camera, 128GB storage, and 5G connectivity.</p>
                    <p class="product-price">$599.99</p>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" onclick="addToCart(2, 'Smartphone', 599.99, 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80')">Add to Cart</button>
                        <a href="product_detail.php?id=2" class="view-details-btn">Details</a>
                    </div>
                </div>
            </div>

            <!-- Product 3 -->
            <div class="product-card">
                <img src="https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80" alt="Laptop" class="product-image">
                <div class="product-info">
                    <h3 class="product-title">Laptop</h3>
                    <p class="product-description">Thin and light laptop with long battery life, 16GB RAM, and 512GB SSD.</p>
                    <p class="product-price">$1299.99</p>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" onclick="addToCart(3, 'Laptop', 1299.99, 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80')">Add to Cart</button>
                        <a href="product_detail.php?id=3" class="view-details-btn">Details</a>
                    </div>
                </div>
            </div>

            <!-- Product 4 -->
            <div class="product-card">
                <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80" alt="Smart Watch" class="product-image">
                <div class="product-info">
                    <h3 class="product-title">Smart Watch</h3>
                    <p class="product-description">Fitness tracker and smartwatch with heart rate monitor and smartphone notifications.</p>
                    <p class="product-price">$199.99</p>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" onclick="addToCart(4, 'Smart Watch', 199.99, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80')">Add to Cart</button>
                        <a href="product_detail.php?id=4" class="view-details-btn">Details</a>
                    </div>
                </div>
            </div>

            <!-- Product 5 -->
            <div class="product-card">
                <img src="https://images.unsplash.com/photo-1505744386214-51dba16a26fc?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80" alt="Bluetooth Speaker" class="product-image">
                <div class="product-info">
                    <h3 class="product-title">Bluetooth Speaker</h3>
                    <p class="product-description">Portable Bluetooth speaker with 360° sound and waterproof design.</p>
                    <p class="product-price">$79.99</p>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" onclick="addToCart(5, 'Bluetooth Speaker', 79.99, 'https://images.unsplash.com/photo-1505744386214-51dba16a26fc?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80')">Add to Cart</button>
                        <a href="product_detail.php?id=5" class="view-details-btn">Details</a>
                    </div>
                </div>
            </div>

            <!-- Product 6 -->
            <div class="product-card">
                <img src="https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80" alt="Gaming Mouse" class="product-image">
                <div class="product-info">
                    <h3 class="product-title">Gaming Mouse</h3>
                    <p class="product-description">High-precision gaming mouse with RGB lighting and programmable buttons.</p>
                    <p class="product-price">$49.99</p>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" onclick="addToCart(6, 'Gaming Mouse', 49.99, 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80')">Add to Cart</button>
                        <a href="product_detail.php?id=6" class="view-details-btn">Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="cart-notification" class="cart-notification">
        <i class="fas fa-check-circle"></i> Product added to cart!
    </div>

    <footer>
        <div class="footer-content">
            <div class="footer-section">
                <h3>TechShop</h3>
                <p>Your one-stop shop for all tech products and electronics.</p>
            </div>
            <div class="footer-section">
                <h3>Contact Us</h3>
                <p><i class="fas fa-map-marker-alt"></i> 123 Tech Street, Tech City</p>
                <p><i class="fas fa-phone"></i> (123) 456-7890</p>
                <p><i class="fas fa-envelope"></i> info@techshop.com</p>
            </div>
            <div class="footer-section">
                <h3>Follow Us</h3>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div class="copyright">
            <p>&copy; 2023 TechShop. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Cart functionality
        let cartCount = 0;
        const cartNotification = document.getElementById('cart-notification');
        const cartCountElement = document.getElementById('cart-count');

        function addToCart(id, name, price, image) {
            cartCount++;
            cartCountElement.textContent = cartCount;
            
            // Show notification
            cartNotification.style.display = 'block';
            
            // Hide notification after 3 seconds
            setTimeout(() => {
                cartNotification.style.display = 'none';
            }, 3000);
            
            // In a real application, you would send this data to your PHP backend
            console.log(`Added to cart: ${name} (ID: ${id}) - $${price}`);
            
            // Example of sending data to PHP (you would implement this in your backend)
            // const formData = new FormData();
            // formData.append('product_id', id);
            // formData.append('product_name', name);
            // formData.append('product_price', price);
            // formData.append('product_image', image);
            // 
            // fetch('add_to_cart.php', {
            //     method: 'POST',
            //     body: formData
            // })
            // .then(response => response.json())
            // .then(data => {
            //     console.log('Product added to cart:', data);
            // })
            // .catch(error => {
            //     console.error('Error:', error);
            // });
        }

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>