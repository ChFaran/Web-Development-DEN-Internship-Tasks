<?php
require_once 'db.php';

try {
    // Create products table
    $sql = "CREATE TABLE IF NOT EXISTS products (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price DECIMAL(10,2) NOT NULL,
        image_url VARCHAR(500),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    
    // Create orders table
    $sql = "CREATE TABLE IF NOT EXISTS orders (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        customer_name VARCHAR(255) NOT NULL,
        customer_email VARCHAR(255) NOT NULL,
        customer_address TEXT NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL,
        order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status ENUM('pending', 'completed', 'cancelled') DEFAULT 'pending'
    )";
    
    $pdo->exec($sql);
    
    // Create order_items table
    $sql = "CREATE TABLE IF NOT EXISTS order_items (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        order_id INT(11) NOT NULL,
        product_id INT(11) NOT NULL,
        product_name VARCHAR(255) NOT NULL,
        product_price DECIMAL(10,2) NOT NULL,
        quantity INT(11) NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    )";
    
    $pdo->exec($sql);
    
    // Insert sample products if they don't exist
    $checkProducts = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    
    if ($checkProducts == 0) {
        $products = [
            ['Wireless Headphones', 'High-quality wireless headphones with noise cancellation and 20-hour battery life.', 99.99, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'],
            ['Smartphone', 'Latest smartphone with high-resolution camera, 128GB storage, and 5G connectivity.', 599.99, 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'],
            ['Laptop', 'Thin and light laptop with long battery life, 16GB RAM, and 512GB SSD.', 1299.99, 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'],
            ['Smart Watch', 'Fitness tracker and smartwatch with heart rate monitor and smartphone notifications.', 199.99, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'],
            ['Bluetooth Speaker', 'Portable Bluetooth speaker with 360° sound and waterproof design.', 79.99, 'https://images.unsplash.com/photo-1505744386214-51dba16a26fc?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'],
            ['Gaming Mouse', 'High-precision gaming mouse with RGB lighting and programmable buttons.', 49.99, 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80']
        ];
        
        $stmt = $pdo->prepare("INSERT INTO products (name, description, price, image_url) VALUES (?, ?, ?, ?)");
        
        foreach ($products as $product) {
            $stmt->execute($product);
        }
    }
    
    echo "Database initialized successfully! <a href='index.php'>Go to Shop</a>";
    
} catch (PDOException $e) {
    die("Database initialization failed: " . $e->getMessage());
}
?>