var typed= new Typed('.text', {
    strings: ["Web Developer", "Frontend Developer", "Freelancer", "Designer"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});