<?php
include 'connect.php';
$id = $_GET['updateid'];
$sql = "Select * from `crud` where ID=$id";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
$name = $row['Name'];
$email = $row['Email'];
$phone = $row['Phone'];
$password = $row['Password'];

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone =  $_POST['phone'];
    $password = $_POST['password'];
    
    $sql="update `crud` set ID=$id, Name='$name', Email='$email', Phone='$phone', Password='$password' where ID='$id'";
    $result=mysqli_query($con,$sql);
    if($result){
        echo "Data updated successfully";
        // header('location:display.php'); // Redirect to display page after successful insertion
    } else {
        die(mysqli_error($con));
    }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crud Operation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <div class="container my-5">
        <form method="post">
            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" placeholder="Enter your name" name="name" autocompelte="off" value ="<?php echo $name; ?>">
            </div><br>
            <div class="form-group">
                <label>Email address</label>
                <input type="email" class="form-control" placeholder="Enter your email" name="email" autocompelte="off" value ="<?php echo $email; ?>">
            </div><br>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="text" class="form-control" placeholder="Enter your phone number" name="phone" autocompelte="off" value ="<?php echo $phone; ?>">
            </div><br>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="text" class="form-control" placeholder="Enter your password" name="password" autocompelte="off" value ="<?php echo $password; ?>">
            </div><br>
            <button type="submit" class="btn btn-primary" name="submit">Update</button>
        </form>
    </div>
</html>