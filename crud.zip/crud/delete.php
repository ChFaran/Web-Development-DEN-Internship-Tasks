<?php
include 'connect.php';
if(isset($_GET['deleteid'])){
    $id = $_GET['deleteid'];

    $sql="delete from `crud` where ID='$id'";
    $result=mysqli_query($con,$sql);
    if($result){
        header('location:display.php'); // Redirect to display page after successful deletion
    } else {
        die(mysqli_error($con));
    }
}
?>