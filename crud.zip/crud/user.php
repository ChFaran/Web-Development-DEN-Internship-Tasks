<?php
include 'connect.php';
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone =  $_POST['phone'];
    $password = $_POST['password'];
    
    $sql="insert into `crud` (name, email, phone, password) values ('$name', '$email', '$phone', '$password')";
    $result=mysqli_query($con,$sql);
    if($result){
        // echo "Data inserted successfully";
        header('location:display.php'); // Redirect to display page after successful insertion
    } else {
        die(mysqli_error($con));
    }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crud Operation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <div class="container my-5">
        <form method="post">
            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" placeholder="Enter your name" name="name" autocompelte="off">
            </div><br>
            <div class="form-group">
                <label>Email address</label>
                <input type="email" class="form-control" placeholder="Enter your email" name="email" autocompelte="off">
            </div><br>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="text" class="form-control" placeholder="Enter your phone number" name="phone" autocompelte="off">
            </div><br>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="text" class="form-control" placeholder="Enter your password" name="password" autocompelte="off">
            </div><br>
            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
        </form>
    </div>
</html>