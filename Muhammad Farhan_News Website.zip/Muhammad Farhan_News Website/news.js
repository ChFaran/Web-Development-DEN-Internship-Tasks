// Configuration
        const API_KEY = "fd07990d4417463f82ef5bd6f0380651";
        const BASE_URL = "https://newsapi.org/v2/";
        const PAGE_SIZE = 9;
        
        // State management
        let currentPage = 1;
        let currentCategory = 'general';
        let currentSearchTerm = '';
        let isLoading = false;
        
        // DOM Elements
        const elements = {
            newsContainer: document.getElementById('newsContainer'),
            loader: document.getElementById('loader'),
            loadMoreBtn: document.getElementById('loadMoreBtn'),
            statusMessage: document.getElementById('statusMessage'),
            lastUpdated: document.getElementById('lastUpdated'),
            searchInput: document.getElementById('searchInput'),
            searchButton: document.getElementById('searchButton'),
            categoryButtons: document.querySelectorAll('.category-chip'),
            mainContent: document.querySelector('main')
        };

        // Initialize
        document.addEventListener('DOMContentLoaded', initApp);

        function initApp() {
            adjustMainHeight();
            setupEventListeners();
            fetchNews();
            updateLastUpdated();
        }

        function setupEventListeners() {
            elements.loadMoreBtn.addEventListener('click', fetchNews);
            elements.searchButton.addEventListener('click', performSearch);
            elements.searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') performSearch();
            });
            
            elements.categoryButtons.forEach(button => {
                button.addEventListener('click', () => handleCategoryChange(button.dataset.category));
            });
            
            window.addEventListener('resize', adjustMainHeight);
        }

        function adjustMainHeight() {
            const headerHeight = document.querySelector('header').offsetHeight;
            const footerHeight = document.querySelector('footer').offsetHeight;
            const windowHeight = window.innerHeight;
            const minHeight = windowHeight - headerHeight - footerHeight - 50;
            
            elements.mainContent.style.minHeight = `${minHeight}px`;
        }

        function handleCategoryChange(category) {
            if (isLoading || currentCategory === category) return;
            
            currentCategory = category;
            currentPage = 1;
            currentSearchTerm = '';
            elements.searchInput.value = '';
            elements.newsContainer.innerHTML = '';
            elements.statusMessage.classList.add('hidden');
            
            // Update active category button
            elements.categoryButtons.forEach(btn => {
                btn.classList.remove('active', 'bg-opacity-90');
                btn.classList.add('bg-opacity-20');
            });
            const activeBtn = document.querySelector(`[data-category="${category}"]`);
            if (activeBtn) {
                activeBtn.classList.add('active', 'bg-opacity-90');
                activeBtn.classList.remove('bg-opacity-20');
            }
            
            fetchNews('top-headlines', { category: currentCategory });
        }

        function performSearch() {
            const searchTerm = elements.searchInput.value.trim();
            
            if (searchTerm === currentSearchTerm) return;
            
            currentSearchTerm = searchTerm;
            currentPage = 1;
            elements.newsContainer.innerHTML = '';
            
            if (currentSearchTerm === '') {
                elements.statusMessage.classList.add('hidden');
                fetchNews('top-headlines', { category: currentCategory });
            } else {
                fetchNews('everything', { q: currentSearchTerm });
                showStatusMessage(`Showing results for: "${currentSearchTerm}"`);
            }
        }

        function fetchNews(endpoint = 'top-headlines', params = {}) {
            if (isLoading) return;
            
            isLoading = true;
            showLoader();
            hideLoadMoreButton();
            
            // Default parameters
            const defaultParams = {
                pageSize: PAGE_SIZE,
                page: currentPage,
                apiKey: API_KEY,
                language: 'en'
            };

            // Merge parameters
            const queryParams = new URLSearchParams({
                ...defaultParams,
                ...params
            });

            // Construct final URL
            const apiUrl = `${BASE_URL}${endpoint}?${queryParams.toString()}`;
            
            fetch(apiUrl)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! Status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.status === "error") {
                        throw new Error(data.message);
                    }
                    handleNewsResponse(data);
                })
                .catch(error => {
                    console.error('Error fetching news:', error);
                    showStatusMessage('Failed to load news. Please try again later.');
                })
                .finally(() => {
                    isLoading = false;
                    hideLoader();
                    adjustMainHeight();
                });
        }

        function handleNewsResponse(data) {
            if (data.articles && data.articles.length > 0) {
                displayArticles(data.articles);
                currentPage++;
                
                if (data.articles.length === PAGE_SIZE) {
                    showLoadMoreButton();
                } else {
                    hideLoadMoreButton();
                }
            } else {
                if (currentPage === 1) {
                    showStatusMessage('No articles found. Try a different search.');
                } else {
                    showStatusMessage('No more articles to load.');
                }
            }
        }

        function displayArticles(articles) {
            articles.forEach(article => {
                const newsCard = createNewsCard(article);
                elements.newsContainer.appendChild(newsCard);
            });
        }

        function createNewsCard(article) {
            const newsCard = document.createElement('div');
            newsCard.className = 'news-card bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg';
            
            const imageUrl = article.urlToImage || 'https://placehold.co/600x400?text=News+Image';
            const description = article.description || 'No description available';
            
            newsCard.innerHTML = `
                <div class="h-48 overflow-hidden">
                    <img src="${imageUrl}" alt="${article.title || 'News image'}" class="w-full h-full object-cover" 
                         onerror="this.onerror=null; this.src='https://placehold.co/600x400?text=Image+Not+Available'">
                </div>
                <div class="p-4">
                    <span class="text-xs text-gray-500">${formatDate(article.publishedAt)}</span>
                    <h3 class="text-lg font-semibold mt-1 mb-2">${article.title || 'No title available'}</h3>
                    <p class="text-gray-600 text-sm mb-4 line-clamp-3">${description}</p>
                    <div class="flex justify-between items-center">
                        <span class="text-xs px-2 py-1 bg-gray-100 rounded-full">${article.source?.name || 'Unknown source'}</span>
                        <a href="${article.url}" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                            Read More →
                        </a>
                    </div>
                </div>
            `;
            
            return newsCard;
        }

        function formatDate(dateString) {
            if (!dateString) return 'No date';
            const options = { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            };
            return new Date(dateString).toLocaleDateString('en-US', options);
        }

        function updateLastUpdated() {
            const now = new Date();
            elements.lastUpdated.textContent = formatDate(now);
        }

        function showLoader() {
            elements.loader.classList.remove('hidden');
        }

        function hideLoader() {
            elements.loader.classList.add('hidden');
        }

        function showLoadMoreButton() {
            elements.loadMoreBtn.classList.remove('hidden');
        }

        function hideLoadMoreButton() {
            elements.loadMoreBtn.classList.add('hidden');
        }

        function showStatusMessage(message) {
            elements.statusMessage.textContent = message;
            elements.statusMessage.classList.remove('hidden');
        }